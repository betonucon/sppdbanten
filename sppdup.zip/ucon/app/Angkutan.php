<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Angkutan extends Model
{
    protected $table = 'angkutan';
    public $timestamps = false;
}
