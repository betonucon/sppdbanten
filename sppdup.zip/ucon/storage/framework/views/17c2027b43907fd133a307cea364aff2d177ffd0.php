<style>
    .dataTables_filter{
        float:right;
    }
    td{
        font-size: 13px;
    }
    th{
        font-size: 13px;
    }
</style>
<?php $__env->startSection('content'); ?>
<section class="content">
      <div class="row">
        <div class="col-xs-12">
            
          

          <div class="box">
            <div class="box-body">
                <form method="post" action="<?php echo e(url('/group/save')); ?>">   
                    <div class="mailbox-controls" style="background:#d6d6e3;margin-bottom:10px">
                        <!-- Check all button -->
                        <?php if(cek_permision_role(2)=='All' || cek_permision_role(2)=='Create'): ?>
                            <span  data-toggle="modal" data-target="#modalreplay" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></span>
                        <?php endif; ?>   
                        
                        <!-- /.btn-group -->
                        <button type="button" class="btn btn-default btn-sm" onclick="reload()"><i class="fa fa-refresh"></i></button>
                        <div class="pull-right">
                        
                        </div>
                        <!-- /.pull-right -->
                    </div>
                
                    <?php echo csrf_field(); ?>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>Jenis SPPD</th>
                                <th>Tujuan</th>
                                <th>Golongan</th>
                                <th>Transportasi</th>
                                <th>Uang Harian</th>
                                <th>Uang Reresentasi</th>
                                <th>Penginapan</th>
                                <th width="8%"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $domlak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$domlak): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+1); ?></td>
                                    <td><?php echo e(jenis_sppd($domlak->jenis_sppd_id)); ?></td>
                                    <td><?php echo e(tujuan_sppd($domlak->tujuan_sppd_id)); ?></td>
                                    <td><?php echo e(cekgolongan($domlak->golongan_id)); ?></td>
                                    <td>Rp.<?php echo e($domlak->transportasi); ?></td>
                                    <td>Rp.<?php echo e($domlak->uang_harian); ?></td>
                                    <td>Rp.<?php echo e($domlak->uang_representasi); ?></td>
                                    <td>Rp.<?php echo e($domlak->uang_penginapan); ?></td>
                                    <td>
                                    <?php if(cek_permision_role(2)=='All' || cek_permision_role(2)=='Create'): ?>
                                        <div class="btn-group">
                                            <span  class="btn btn-default btn-sm" onclick="delete_data(<?php echo e($domlak->id); ?>)"><i class="fa fa-trash-o"></i></span>
                                            <span  data-toggle="modal" data-target="#modalreplay<?php echo e($domlak->id); ?>" class="btn btn-default btn-sm"><i class="fa fa-pencil"></i></span>
                                        </div>
                                    <?php else: ?>
                                        No Akses
                                    <?php endif; ?>
                                    </td>
                                 </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                </form>
            </div>
            <!-- /.box-body -->
          </div>
         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
</section>
<?php $__currentLoopData = $modaldomlak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$modalpegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalreplay<?php echo e($modalpegawai->id); ?>">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Form SSH</h4>
            </div>
            <form method="post" id="myform<?php echo e($modalpegawai->id); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($modalpegawai->id); ?>">
                <div class="modal-body">
                    <div id="alertnya<?php echo e($modalpegawai->id); ?>" style="padding:10px;background:#dfdff7;font-weight:bold">
                    </div>
                    <div class="form-group">
                        <label>Jenis SPPD:</label>
                        <select class="form-control select2" onchange="caritujuannew(this.value,<?php echo e($modalpegawai->id); ?>)" name="jenis_sppd_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            <option value="">Pilih Jenis SPPD</option>
                            <?php $__currentLoopData = pilih_jenis_sppd(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sppd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sppd->id); ?>" <?php if($modalpegawai->jenis_sppd_id==$sppd->id): ?> selected <?php endif; ?> > <?php echo e($sppd->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tujuan SPPD:</label>
                        <select class="form-control select2" id="tujuan<?php echo e($modalpegawai->id); ?>" onchange="carijumlah(this.value)" name="tujuan_sppd_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            
                            <?php if($modalpegawai->tujuan_sppd_id!=''): ?>
                                <option value="<?php echo e($modalpegawai->tujuan_sppd_id); ?> "><?php echo e(tujuan_sppd($modalpegawai->tujuan_sppd_id)); ?></option>
                            <?php else: ?>
                                <option value="">Pilih Tujuan</option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Angkutan yang dipergunakan:</label>
                        <select class="form-control select2"  name="angkutan_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            <option value="">Pilih Angkutan</option>
                            <?php $__currentLoopData = pilih_angkutan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angkutan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($angkutan->id); ?>" <?php if($modalpegawai->angkutan_id==$angkutan->id): ?> selected <?php endif; ?>> <?php echo e($angkutan->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Golongan:</label>
                        <select class="form-control select2"  name="golongan_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            <option value="">Pilih golongan</option>
                            
                            <?php $__currentLoopData = golongan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $golongan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($golongan->id); ?>" <?php if($modalpegawai->golongan_id==$golongan->id): ?> selected <?php endif; ?>> <?php echo e($golongan->golongan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Transportasi:</label>
                        <input type="text" class="form-control" id="transportasi"  value="<?php echo e($modalpegawai->transportasi); ?>" name="transportasi">
                    </div>
                    <div class="form-group">
                        <label>Uang Harian:</label>
                        <input type="text" class="form-control" id="uang_harian"  value="<?php echo e($modalpegawai->uang_harian); ?>"  name="uang_harian">
                    </div>
                    <div class="form-group">
                        <label>Uang Repesentasi:</label>
                        <input type="text" class="form-control" id="uang_representasi"  value="<?php echo e($modalpegawai->uang_repesentasi); ?>"  name="uang_representasi">
                    </div>
                    <div class="form-group">
                        <label>Uang Penginapan:</label>
                        <input type="text" class="form-control" id="uang_penginapan"  value="<?php echo e($modalpegawai->uang_penginapan); ?>"  name="uang_penginapan">
                    </div>
                    
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default " data-dismiss="modal">Tutup</button>
                    <button type="button" id="simpan<?php echo e($modalpegawai->id); ?>" Onclick="simpan_data(<?php echo e($modalpegawai->id); ?>);" class="btn btn-primary pull-left">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalreplay">
    <div class="modal-dialog modal-lg">
        <div class="modal-content ">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Form SSH</h4>
            </div>
            <form method="post" id="myform" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div id="alertnya" style="padding:10px;background:#dfdff7;font-weight:bold">
                    </div>
                    <div class="form-group">
                        <label>Jenis SPPD:</label>
                        <select class="form-control select2" onchange="caritujuan(this.value)" name="jenis_sppd_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            <option value="">Pilih Jenis SPPD</option>
                            <?php $__currentLoopData = pilih_jenis_sppd(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sppd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sppd->id); ?>"> <?php echo e($sppd->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Tujuan SPPD:</label>
                        <select class="form-control select2" id="tujuan" onchange="carijumlah(this.value)" name="tujuan_sppd_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            <option value="">Pilih Tujuan</option>
                            
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Angkutan yang dipergunakan:</label>
                        <select class="form-control select2"  name="angkutan_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            <option value="">Pilih Angkutan</option>
                            <?php $__currentLoopData = pilih_angkutan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angkutan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($angkutan->id); ?>"> <?php echo e($angkutan->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Golongan:</label>
                        <select class="form-control select2"  name="golongan_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            <option value="">Pilih golongan</option>
                            <?php $__currentLoopData = golongan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $golongan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($golongan->id); ?>"> <?php echo e($golongan->golongan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Transportasi:</label>
                        <input type="text" class="form-control" id="transportasi"  name="transportasi">
                    </div>
                    <div class="form-group">
                        <label>Uang Harian:</label>
                        <input type="text" class="form-control" id="uang_harian"  name="uang_harian">
                    </div>
                    <div class="form-group">
                        <label>Uang Repesentasi:</label>
                        <input type="text" class="form-control" id="uang_representasi"  name="uang_representasi">
                    </div>
                    <div class="form-group">
                        <label>Uang Penginapan:</label>
                        <input type="text" class="form-control" id="uang_penginapan"  name="uang_penginapan">
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default " data-dismiss="modal">Tutup</button>
                    <button type="button" id="simpan" Onclick="simpan_data_()" class="btn btn-primary pull-left">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="notifikasi">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Warning</h4>
            </div>
            <div class="modal-body">
                <div id="alertnyas" style="padding:10px;background:#dfdff7;font-weight:bold;text-align:center">
                    <h4>Sukses Tersimpan</h4>
                </div>
            </div>
            <div class="modal-footer">
            <span  class="btn btn-default pull-left" data-dismiss="modal">Close</span>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="notifikasidelete">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Warning</h4>
            </div>
            <div class="modal-body">
                <div id="alertnyas" style="padding:10px;background:#dfdff7;font-weight:bold;text-align:center">
                    <h4>Sukses Terhapus</h4>
                </div>
            </div>
            <div class="modal-footer">
            <span  class="btn btn-default pull-left" data-dismiss="modal">Close</span>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('datatable'); ?>
<?php $__currentLoopData = $alert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script>
        $( document ).ready(function() {
            $("#alertnya<?php echo e($alert->id); ?>").hide();
        });

    </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>

function print(){
    window.location.assign("<?php echo e(url('/employe/pdf/employe')); ?>");
}

function download(){
    window.location.assign("<?php echo e(url('/employe/pdf/download')); ?>");
}

function reload(){
    location.reload();
}
function caritujuan(a){
    $("#tujuan").load("<?php echo e(url('/domlak/tujuan/')); ?>/"+a);
}
function caritujuannew(a,b){
    $("#tujuan"+b).load("<?php echo e(url('/domlak/tujuan/')); ?>/"+a);
}
function delete_data(a){
    $.ajax({
        type: 'GET',
        url: "<?php echo e(url('/employe/delete/')); ?>/"+a,
        data: 'id='+a,
        success: function(msg){
            
            window.location.assign("<?php echo e(url('/employe/hapus')); ?>");
            
        }
    });
}
  $(function () {
    $('#example1').DataTable({
        'paging'      : true,
        'lengthChange': true,
        'searching'   : true,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false
    })
  })
</script>
<script>
    $( document ).ready(function() {
        $('#alertnya').hide();
    });
    <?php if($notif=='sukses'): ?>
        $('#notifikasi').modal("toggle");
    <?php endif; ?>

    <?php if($notif=='hapus'): ?>
        $('#notifikasidelete').modal("toggle");
    <?php endif; ?>

    function simpan_data_(){
        var form=document.getElementById('myform');
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('/domlak/save/new')); ?>",
          data: new FormData(form),
          contentType: false,
          cache: false,
          processData:false,
          beforeSend: function(){
            $('#simpan').attr("disabled","disabled");
          },
          success: function(msg){
            if(msg=='ok'){
                window.location.assign("<?php echo e(url('/domlak/sukses')); ?>");
            }else{
              $('#alertnya').show();
              $('#alertnya').html(msg);
              $("#simpan").removeAttr("disabled");
            }
            
          }
        });
        //alert('dfdsfsd');
    }

    function simpan_data(a){
        var form=document.getElementById('myform'+a);
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('/domlak/save/edit')); ?>",
          data: new FormData(form),
          contentType: false,
          cache: false,
          processData:false,
          beforeSend: function(){
            $('#simpan'+a).attr("disabled","disabled");
          },
          success: function(msg){
            if(msg=='ok'){
                window.location.assign("<?php echo e(url('/domlak/sukses')); ?>");
            }else{
              $('#alertnya'+a).show();
              $('#alertnya'+a).html(msg);
              $("#simpan"+a).removeAttr("disabled");
            }
            
          }
        });
        //alert('dfdsfsd');
    }

    
    function delete_group(){
        var form=document.getElementById('formdelete');
        $.ajax({
			type: 'POST',
			url: "<?php echo e(url('/group/delete')); ?>",
			data: new FormData(form),
			contentType: false,
			cache: false,
			processData:false,
			success: function(msg){
				window.location.assign("<?php echo e(url('/group')); ?>");
				
			}
		});
    }

    function edit_group(a){
        var form=document.getElementById('save'+a);
        $.ajax({
			type: 'POST',
			url: "<?php echo e(url('/group/update')); ?>/"+a,
			data: new FormData(form),
			contentType: false,
			cache: false,
			processData:false,
			beforeSend: function(){
				$('#simpan'+a).attr("disabled","disabled");
			},
			success: function(msg){
				if(msg=='ok'){
					window.location.assign("<?php echo e(url('/guru/suksess')); ?>");
				}else{
					$('#alert'+a).show();
					$('#alert'+a).html(msg);
					$("#simpan"+a).removeAttr("disabled");
				}
				
			}
		});
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('html.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>