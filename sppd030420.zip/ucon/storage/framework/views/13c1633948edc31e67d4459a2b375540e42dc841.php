<style>
    .dataTables_filter{
        float:right;
    }
    td{
        font-size: 13px;
    }
    th{
        font-size: 13px;
    }
    .ttd{
        padding:5px;
        background:#e9e9f3;
        border:solid 1px #fff;
    }
</style>
<?php $__env->startSection('content'); ?>
<section class="content">
      <div class="row">
        <div class="col-xs-12">
            
          

          <div class="box">
            <div class="box-body">
                <form method="post" action="<?php echo e(url('/group/save')); ?>">   
                    <div class="mailbox-controls" style="background:#d6d6e3;margin-bottom:10px">
                        <!-- Check all button -->
                        
                            <span  class="btn btn-success btn-sm" onclick="print()"><i class="fa fa-print"></i></span>
                            <span  class="btn btn-default btn-sm" onclick="download()"><i class="fa fa-download"></i></span>
                            
                        
                        <!-- /.btn-group -->
                        <button type="button" class="btn btn-default btn-sm" onclick="reload()"><i class="fa fa-refresh"></i></button>
                        <div class="pull-right">
                        
                        </div>
                        <!-- /.pull-right -->
                    </div>
                
                    <?php echo csrf_field(); ?>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>Tgl Surat</th>
                                <th>Judul Surat</th>
                                <th>Nomor Surat</th>
                                <th>Kegiatan</th>
                                <th>Status</th>
                                <th width="5%">View</th>
                                <th width="5%">SPPD</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+1); ?></td>
                                    <td><?php echo e($data->date_surat); ?></td>
                                    <td><?php echo e($data->judul_surat); ?></td>
                                    <td><?php echo e($data->nomor_surat); ?></td>
                                    <td><?php echo e(cek_kegiatan($data->kegiatan_id)); ?></td>
                                    <td><?php echo status($data->sts); ?></td>
                                    <td><span  class="btn btn-default btn-sm" onclick="detail(<?php echo e($data->id); ?>)"><i class="fa fa-search"></i></span></td>
                                    <td><span  class="btn btn-default btn-sm" onclick="cetak_sppd(<?php echo e($data->id); ?>)"><i class="fa fa-print"></i></span></td>
                                            
                                    
                                 </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                </form>
            </div>
            <!-- /.box-body -->
          </div>
         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
</section>
<?php $__currentLoopData = $modaldata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$modalpegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalreplay<?php echo e($modalpegawai->id); ?>">
    <div class="modal-dialog modal-lg" style="width:85%">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Form Surat Tugas</h4>
            </div>
            <form method="post" id="myform<?php echo e($modalpegawai->id); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($modalpegawai->id); ?>">
                <div class="modal-body">
                    <div id="alertnya<?php echo e($modalpegawai->id); ?>" style="padding:10px;background:#dfdff7;font-weight:bold">
                    </div>
                    <div class="md-kiri">
                        <h4 class="modal-title">Informasi Surat Tugas</h4><hr style="border-top: 1px solid #d2aeae;margin-top: 10px;margin-bottom: 15px;">
                        <div class="form-group">
                            <label>Tanggal Surat:</label>
                            <div class="input-group date">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" value="<?php echo e($modalpegawai->date_surat); ?>" name="date_surat" class="form-control pull-right" id="datepicker1<?php echo e($modalpegawai->id); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Tanggal Tugas:</label>
                            <div class="input-group date">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" value="<?php echo e($modalpegawai->date_mulai); ?>" name="date_mulai" class="form-control pull-right" id="datepicker2<?php echo e($modalpegawai->id); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Tanggal Selesai:</label>
                            <div class="input-group date">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" value="<?php echo e($modalpegawai->date_sampai); ?>" name="date_sampai" class="form-control pull-right" id="datepicker3<?php echo e($modalpegawai->id); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Nomor Surat:</label>
                            <input type="text" readonly value="<?php echo e($modalpegawai->nomor_surat); ?>" class="form-control" id="nomor_surat" value="<?php echo e(nomor()); ?>" name="nomor_surat">
                        </div>
                        <div class="form-group">
                            <label>Judul Surat:</label>
                            <input type="text" value="<?php echo e($modalpegawai->judul_surat); ?>" class="form-control" id="judul_surat" name="judul_surat">
                        </div>
                        <div class="form-group">
                            <label>Nomor SPPD:</label>
                            <input type="text" value="<?php echo e($modalpegawai->nomor_sppd); ?>" class="form-control" id="nomor_sppd" name="nomor_sppd">
                        </div>
                        <div class="form-group">
                            <label>Nama Kegiatan:</label>
                            <select class="form-control select2" onchange="carijumlah(this.value,<?php echo e($modalpegawai->id); ?>)" name="kegiatan_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                                <option value="">Pilih Kegiatan</option>
                                <?php $__currentLoopData = kegiatan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kegiatan->id); ?>" <?php if($modalpegawai->kegiatan_id==$kegiatan->id): ?> selected <?php endif; ?>> <?php echo e($kegiatan->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Jumlah Pegawai:</label>
                            <input type="text" readonly class="form-control" value="<?php echo e($modalpegawai->jumlah); ?>" id="jumlah<?php echo e($modalpegawai->id); ?>" name="jumlah">
                        </div>
                        <div class="form-group">
                            <label>Pejabat Berwenang:</label>
                            <select class="form-control select2"  name="pejabat_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                                <option value="">Pilih Pejabat</option>
                                <?php $__currentLoopData = pilih_employe(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employe->id); ?>" <?php if($modalpegawai->pejabat_id==$employe->id): ?> selected <?php endif; ?>> <?php echo e($employe->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Jenis SPPD:</label>
                            <select class="form-control select2" onchange="cekcaritujuan(this.value,<?php echo e($modalpegawai->id); ?>)" name="jenis_sppd_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                                <option value="">Pilih Jenis SPPD</option>
                                <?php $__currentLoopData = pilih_jenis_sppd(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sppd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sppd->id); ?>" <?php if($modalpegawai->jenis_sppd_id==$sppd->id): ?> selected <?php endif; ?>> <?php echo e($sppd->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Tujuan SPPD:</label>
                            <select class="form-control select2" id="tujuan<?php echo e($modalpegawai->id); ?>"  name="tujuan_sppd_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                                
                                <?php if($modalpegawai->tujuan_sppd_id!=''): ?>
                                    <option value="<?php echo e($modalpegawai->tujuan_sppd_id); ?> "><?php echo e(tujuan_sppd($modalpegawai->tujuan_sppd_id)); ?></option>
                                <?php else: ?>
                                    <option value="">Pilih Tujuan</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Dalam rangka Kunjungan Kerja:</label>
                            <input type="text"  class="form-control" id="kunjungan" value="<?php echo e($modalpegawai->kunjungan); ?>" name="kunjungan">
                        </div>
                        <div class="form-group">
                            <label>Tempat Tujuan:</label>
                            <input type="text"  class="form-control" id="tujuannya" value="<?php echo e($modalpegawai->tujuan); ?>" name="tujuan">
                        </div>
                        
                        <button type="button" class="btn btn-default " data-dismiss="modal">Tutup</button>
                        <button type="button" id="simpan<?php echo e($modalpegawai->id); ?>" Onclick="simpan_data(<?php echo e($modalpegawai->id); ?>);" class="btn btn-primary pull-left">Simpan</button>
                    </div>
                    <div class="md-kanan">
                    <h4 class="modal-title">Angkutan dan Layanan Pemesanan Tiket</h4><hr style="border-top: 1px solid #d2aeae;margin-top: 10px;margin-bottom: 15px;">
                        <div class="form-group">
                            <label>Angkutan yang dipergunakan:</label>
                            <select class="form-control select2"  name="angkutan_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                                <option value="">Pilih Angkutan</option>
                                <?php $__currentLoopData = pilih_angkutan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angkutan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($angkutan->id); ?>" <?php if($modalpegawai->angkutan_id==$angkutan->id): ?> selected <?php endif; ?>> <?php echo e($angkutan->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Layanan Pemesanan Tiket:</label>
                            <select class="form-control select2"  name="jasa_perjalanan_id" style="width: 100%;" data-select2-id="10" tabindex="-1" aria-hidden="true">
                                <option value="">Pilih Layanan</option>
                                <?php $__currentLoopData = jasaperjalanan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jasa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($jasa->id); ?>" <?php if($modalpegawai->jasa_perjalanan_id==$jasa->id): ?> selected <?php endif; ?>> <?php echo e($jasa->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <h4 class="modal-title">Keterangan Surat Tugas</h4><hr style="border-top: 1px solid #d2aeae;margin-top: 10px;margin-bottom: 15px;">
                        <div class="form-group">
                            <label>Dasar:</label>
                            <textarea  class="form-control" id="dasar"  rows="4" name="dasar"><?php echo e($modalpegawai->dasar); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Maksud:</label>
                            <textarea  class="form-control" id="maksud" rows="4" name="maksud"><?php echo e($modalpegawai->maksud); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Catatan:</label>
                            <textarea  class="form-control" id="catatan" rows="4" name="catatan"><?php echo e($modalpegawai->catatan); ?></textarea>
                        </div>
                        
                    </div>
                </div>
                <div class="modal-footer">
                    
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="person<?php echo e($modalpegawai->id); ?>">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Detail Surat Tugas</h4>
            </div>
            <div class="modal-body">
                <form method="post" id="detailmyform<?php echo e($modalpegawai->id); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($modalpegawai->id); ?>" name="surat_tugas_id">
                    <input type="hidden" id="jenis_sppd_id<?php echo e($modalpegawai->id); ?>" value="<?php echo e($modalpegawai->jenis_sppd_id); ?>" name="jenis_sppd_id">
                    <input type="hidden" id="angkutan_id<?php echo e($modalpegawai->id); ?>" value="<?php echo e($modalpegawai->angkutan_id); ?>" name="angkutan_id">
                    <input type="hidden" id="tujuan_sppd_id<?php echo e($modalpegawai->id); ?>" value="<?php echo e($modalpegawai->tujuan_sppd_id); ?>" name="angkutan_id">
                    <table width="100%" border="1" >
                        <tr>
                            <td class="ttd" width="5%">No</td>
                            <td class="ttd">Pegawai</td>
                            <td class="ttd" width="13%">Transport</td>
                            <td class="ttd" width="13%">Harian</td>
                            <td class="ttd" width="13%">Resepresentasi</td>
                            <td class="ttd" width="13%">Penginapan</td>
                        
                        </tr>
                        <?php for($x=0;$x<$modalpegawai->jumlah;$x++): ?>
                        <tr>
                            <td class="ttd" align="center"><?php echo e($x+1); ?></td>
                            <td class="ttd">
                                <select class="form-control select2" onchange="cekbiaya(this.value,<?php echo e($modalpegawai->id); ?>,<?php echo e($x); ?>)" name="pegawai_id[]" style="width: 100%;" data-select2-id="<?php echo e($modalpegawai->id); ?><?php echo e($x); ?>" tabindex="-1" aria-hidden="true">
                                    <option value="">Pilih Pegawai</option>
                                    <?php $__currentLoopData = pegawai(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($pegawai->id); ?>" <?php echo e($pegawai_id->shift()['selected']); ?>  > <?php echo e($pegawai->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td class="ttd">
                                <input type="text" readonly name="transportasi[]" value="<?php echo e($transportasi->shift()['transportasi']); ?>" id="transportasi<?php echo e($modalpegawai->id); ?><?php echo e($x); ?>" class="form-control">
                            </td>
                            <td class="ttd">
                                <input type="text" readonly name="harian[]" value="<?php echo e($harian->shift()['harian']); ?>" id="harian<?php echo e($modalpegawai->id); ?><?php echo e($x); ?>" class="form-control">
                            </td>
                            <td class="ttd">
                                <input type="text" readonly name="representasi[]" value="<?php echo e($representasi->shift()['representasi']); ?>" id="representasi<?php echo e($modalpegawai->id); ?><?php echo e($x); ?>" class="form-control">
                            </td>
                            <td class="ttd">
                                <input type="text" readonly name="penginapan[]" value="<?php echo e($penginapan->shift()['penginapan']); ?>" id="penginapan<?php echo e($modalpegawai->id); ?><?php echo e($x); ?>" class="form-control">
                                <input type="hidden" readonly name="id[]" value="<?php echo e($id->shift()['id']); ?>" class="form-control">
                            </td>
                        </tr>
                        <?php endfor; ?>
                    </table>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default " data-dismiss="modal">Tutup</button>
                <button type="button" id="simpan_detail<?php echo e($modalpegawai->id); ?>" Onclick="simpan_data_detail(<?php echo e($modalpegawai->id); ?>)" class="btn btn-primary pull-left">Simpan</button>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="modal fade" id="modalreplay">
    <div class="modal-dialog modal-lg" style="width:85%">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Form Surat Tugas</h4>
            </div>
            <form method="post" id="myform" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div id="alertnya" style="padding:10px;background:#dfdff7;font-weight:bold">
                    </div>
                    <div class="md-kiri">
                        <h4 class="modal-title">Informasi Surat Tugas</h4><hr style="border-top: 1px solid #d2aeae;margin-top: 10px;margin-bottom: 15px;">
                        <div class="form-group">
                            <label>Tanggal Surat:</label>
                            <div class="input-group date">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" name="date_surat" class="form-control pull-right" id="datepickers">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Tanggal Tugas:</label>
                            <div class="input-group date">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" name="date_mulai" class="form-control pull-right" id="datepickers1">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Tanggal Selesai:</label>
                            <div class="input-group date">
                                <div class="input-group-addon">
                                    <i class="fa fa-calendar"></i>
                                </div>
                                <input type="text" name="date_sampai" class="form-control pull-right" id="datepickers2">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Nomor Surat:</label>
                            <input type="text" readonly class="form-control" id="nomor_surat" value="<?php echo e(nomor()); ?>" name="nomor_surat">
                        </div>
                        <div class="form-group">
                            <label>Judul Surat:</label>
                            <input type="text" class="form-control" id="judul_surat" name="judul_surat">
                        </div>
                        <div class="form-group">
                            <label>Nomor SPPD:</label>
                            <input type="text" class="form-control" id="nomor_sppd" name="nomor_sppd">
                        </div>
                        <div class="form-group">
                            <label>Nama Kegiatan:</label>
                            <select class="form-control select2" onchange="carijumlah_(this.value)" name="kegiatan_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                                <option value="">Pilih Kegiatan</option>
                                <?php $__currentLoopData = kegiatan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kegiatan->id); ?>"> <?php echo e($kegiatan->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Jumlah Pegawai:</label>
                            <input type="text" readonly class="form-control" id="jumlah" name="jumlah">
                        </div>
                        <div class="form-group">
                            <label>Pejabat Berwenang:</label>
                            <select class="form-control select2"  name="pejabat_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                                <option value="">Pilih Pejabat</option>
                                <?php $__currentLoopData = pilih_employe(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employe->id); ?>"> <?php echo e($employe->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Jenis SPPD:</label>
                            <select class="form-control select2" onchange="caritujuan(this.value)" name="jenis_sppd_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                                <option value="">Pilih Jenis SPPD</option>
                                <?php $__currentLoopData = pilih_jenis_sppd(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sppd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sppd->id); ?>"> <?php echo e($sppd->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Tujuan SPPD:</label>
                            <select class="form-control select2" id="tujuan"  name="tujuan_sppd_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                                <option value="">Pilih Tujuan</option>
                                
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Dalam rangka Kunjungan Kerja:</label>
                            <input type="text"  class="form-control" id="kunjungan"  name="kunjungan">
                        </div>
                        <div class="form-group">
                            <label>Tempat Tujuan:</label>
                            <input type="text"  class="form-control" id="tujuan" name="tujuan">
                        </div>
                        
                        
                        <button type="button" class="btn btn-default " data-dismiss="modal">Tutup</button>
                        <button type="button" id="simpan" Onclick="simpan_data_()" class="btn btn-primary pull-left">Simpan</button>
                    </div>
                    <div class="md-kanan">
                        <h4 class="modal-title">Angkutan dan Layanan Pemesanan Tiket</h4><hr style="border-top: 1px solid #d2aeae;margin-top: 10px;margin-bottom: 15px;">
                        <div class="form-group">
                            <label>Angkutan yang dipergunakan:</label>
                            <select class="form-control select2"  name="angkutan_id" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                                <option value="">Pilih Angkutan</option>
                                <?php $__currentLoopData = pilih_angkutan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $angkutan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($angkutan->id); ?>"> <?php echo e($angkutan->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Layanan Pemesanan Tiket:</label>
                            <select class="form-control select2"  name="jasa_perjalanan_id" style="width: 100%;" data-select2-id="10" tabindex="-1" aria-hidden="true">
                                <option value="">Pilih Layanan</option>
                                <?php $__currentLoopData = jasaperjalanan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jasa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($jasa->id); ?>"> <?php echo e($jasa->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <h4 class="modal-title">Keterangan Surat Tugas</h4><hr style="border-top: 1px solid #d2aeae;margin-top: 10px;margin-bottom: 15px;">
                        <div class="form-group">
                            <label>Dasar:</label>
                            <textarea  class="form-control" id="dasar"  rows="4" name="dasar"></textarea>
                        </div>
                        <div class="form-group">
                            <label>Maksud:</label>
                            <textarea  class="form-control" id="maksud" rows="4" name="maksud"></textarea>
                        </div>
                        <div class="form-group">
                            <label>Catatan:</label>
                            <textarea  class="form-control" id="catatan" rows="4" name="catatan"></textarea>
                        </div>
                        
                    </div>
                </div>
                    
                <div class="modal-footer" style="width:100%">
                    
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="notifikasi">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Warning</h4>
            </div>
            <div class="modal-body">
                <div id="alertnyas" style="padding:10px;background:#dfdff7;font-weight:bold;text-align:center">
                    <h4>Sukses Tersimpan</h4>
                </div>
            </div>
            <div class="modal-footer">
            <span  class="btn btn-default pull-left" onclick="close_notif()">Close</span>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="notifikasidelete">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Warning</h4>
            </div>
            <div class="modal-body">
                <div id="alertnyas" style="padding:10px;background:#dfdff7;font-weight:bold;text-align:center">
                    <h4>Sukses Terhapus</h4>
                </div>
            </div>
            <div class="modal-footer">
            <span  class="btn btn-default pull-left" data-dismiss="modal">Close</span>
            </div>
        </div>
    </div>
</div>
<?php $__currentLoopData = $alert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <?php $__env->startPush('datepicker'); ?>
    <script>
        $('#datepicker1<?php echo e($alert->id); ?>').datepicker({
            format: 'yyyy-mm-dd'
        });
        $('#datepicker2<?php echo e($alert->id); ?>').datepicker({
            format: 'yyyy-mm-dd'
        });
        $('#datepicker3<?php echo e($alert->id); ?>').datepicker({
            format: 'yyyy-mm-dd'
        });
    </script>
    <script>
        $( document ).ready(function() {
            $("#alertnya<?php echo e($alert->id); ?>").hide();
        });

        $('#datepickerok<?php echo e($alert->id); ?>').datepicker({
            format: 'yyyy-mm-dd'
        });

        
    </script>
    <?php $__env->stopPush(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->startPush('datatable'); ?>

<script>

function close_notif(){
    window.location.assign("<?php echo e(url('/surat_tugas/')); ?>");
}
function print(){
    window.location.assign("<?php echo e(url('/surat_tugas/pdf/surat_tugas')); ?>");
}

function download(){
    window.location.assign("<?php echo e(url('/golongan/pdf/download')); ?>");
}

function reload(){
    location.reload();
}

function caritujuan(a){
    
    $("#tujuan").load("<?php echo e(url('/surat_tugas/tujuan/')); ?>/"+a);
}
function cekcaritujuan(a,b){
    $("#tujuan"+b).load("<?php echo e(url('/surat_tugas/tujuan/')); ?>/"+a);
}
function cetak_sppd(a){
    window.location.assign("<?php echo e(url('/surat_tugas/pdf/sppd/')); ?>/"+a);
}
function cetak_kwitansi(a){
    window.location.assign("<?php echo e(url('/surat_tugas/pdf/kwitansi/')); ?>/"+a);
}
function detail(a){
    window.location.assign("<?php echo e(url('/surat_tugas/detail/')); ?>/"+a);
}

function delete_data(a){
    $.ajax({
        type: 'GET',
        url: "<?php echo e(url('/golongan/delete/')); ?>/"+a,
        data: 'id='+a,
        success: function(msg){
            
            window.location.assign("<?php echo e(url('/golongan/hapus')); ?>");
            
        }
    });
}

function cekbiaya(z,a,b){
    var jenis_sppd_id=$("#jenis_sppd_id"+a).val();
    var angkutan_id=$("#angkutan_id"+a).val();
    var tujuan_sppd_id=$("#tujuan_sppd_id"+a).val();
    //alert(tujuan_sppd_id);
    $.ajax({
        type: 'GET',
        url: "<?php echo e(url('/surat_tugas/ceknilai/')); ?>/"+z+"/"+jenis_sppd_id+"/"+angkutan_id+"/"+tujuan_sppd_id,
        data: 'a=1',
        success: function(msg){
            nilai=msg.split("-");
            $('#transportasi'+a+''+b).val(nilai[0]);
            $('#harian'+a+''+b).val(nilai[1]);
            $('#representasi'+a+''+b).val(nilai[2]);
            $('#penginapan'+a+''+b).val(nilai[3]);
            
        }
    });
    //alert(a);
    
}

function carijumlah_(a){
    
    $.ajax({
        type: 'GET',
        url: "<?php echo e(url('/surat_tugas/cari/')); ?>/"+a,
        data: 'id='+a,
        success: function(msg){
            
            $('#jumlah').val(msg);
           
        }
    });
}
function carijumlah(a,b){
    
    $.ajax({
        type: 'GET',
        url: "<?php echo e(url('/surat_tugas/cari/')); ?>/"+a,
        data: 'id='+a,
        success: function(msg){
            
            $('#jumlah'+b).val(msg);
           
        }
    });
}
  $(function () {
    $('#example1').DataTable({
        'paging'      : true,
        'lengthChange': true,
        'searching'   : true,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false
    })
  })
</script>
<script>
//$('#notifikasi').modal({ keyboard: true })
    $( document ).ready(function() {
        $('#alertnya').hide();
    });
    <?php if($notif=='sukses'): ?>
        $('#notifikasi').modal({
    		backdrop: 'static',
    		keyboard: false});
    <?php endif; ?>

    <?php if($notif=='hapus'): ?>
        $('#notifikasidelete').modal("toggle");
    <?php endif; ?>

   
    // $(document).ready(function(){
	//     $('#modalreplay').click(function(){
    //         $('#modalreplay').modal({
    //             backdrop: 'static',
    //             keyboard: false
    //         });
	//     });
    // });
    function simpan_data_(){
        var form=document.getElementById('myform');
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('/surat_tugas/save/new')); ?>",
          data: new FormData(form),
          contentType: false,
          cache: false,
          processData:false,
          beforeSend: function(){
            $('#simpan').attr("disabled","disabled");
          },
          success: function(msg){
            if(msg=='ok'){
                window.location.assign("<?php echo e(url('/surat_tugas/sukses')); ?>");
            }else{
              $('#alertnya').show();
              $('#alertnya').html(msg);
              $("#simpan").removeAttr("disabled");
            }
            
          }
        });
        //alert('dfdsfsd');
    }

    function simpan_data_detail(a){
        var form=document.getElementById('detailmyform'+a);
       
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('/surat_tugas/save_detail')); ?>",
          data: new FormData(form),
          contentType: false,
          cache: false,
          processData:false,
          beforeSend: function(){
            $('#simpan_detail'+a).attr("disabled","disabled");
          },
          success: function(msg){
            if(msg=='ok'){
                window.location.assign("<?php echo e(url('/surat_tugas/sukses')); ?>");
            }else{
              $('#alertnya'+a).show();
              $('#alertnya'+a).html(msg);
              $("#simpan_detail"+a).removeAttr("disabled");
            }
            
            
          }
        });
    }
    function simpan_data(a){
        var form=document.getElementById('myform'+a);
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('/surat_tugas/save/edit')); ?>",
          data: new FormData(form),
          contentType: false,
          cache: false,
          processData:false,
          beforeSend: function(){
            $('#simpan'+a).attr("disabled","disabled");
          },
          success: function(msg){
            if(msg=='ok'){
                window.location.assign("<?php echo e(url('/surat_tugas/sukses')); ?>");
            }else{
              $('#alertnya'+a).show();
              $('#alertnya'+a).html(msg);
              $("#simpan"+a).removeAttr("disabled");
            }
            
          }
        });
        //alert('dfdsfsd');
    }

    
    function delete_group(){
        var form=document.getElementById('formdelete');
        $.ajax({
			type: 'POST',
			url: "<?php echo e(url('/group/delete')); ?>",
			data: new FormData(form),
			contentType: false,
			cache: false,
			processData:false,
			success: function(msg){
				window.location.assign("<?php echo e(url('/group')); ?>");
				
			}
		});
    }

    function edit_group(a){
        var form=document.getElementById('save'+a);
        $.ajax({
			type: 'POST',
			url: "<?php echo e(url('/group/update')); ?>/"+a,
			data: new FormData(form),
			contentType: false,
			cache: false,
			processData:false,
			beforeSend: function(){
				$('#simpan'+a).attr("disabled","disabled");
			},
			success: function(msg){
				if(msg=='ok'){
					window.location.assign("<?php echo e(url('/guru/suksess')); ?>");
				}else{
					$('#alert'+a).show();
					$('#alert'+a).html(msg);
					$("#simpan"+a).removeAttr("disabled");
				}
				
			}
		});
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('html.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>