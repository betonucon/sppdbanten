<html>
    <head>
        <title>Surat SPPD</title>
        <style>

            @font-face {
                font-family: 'Textur';
                src: url({{storage_path('fonts/textfont.ttf')}})  format('truetype');
            }
            body {
                font-family:'textfont',Arial, Helvetica, sans-serif;
                color:#000;
            }
            html { 
                margin: 35px;
              
            }
            
            table{
                border-collapse:collapse;
                font-weight:bold;
            }
            th{
               
                padding:2px;
                font-size:11px;
            }
            td{
                /* border:solid 1px #000; */
                padding:0px;
                font-size:13px;
                vertical-align:top;
                font-weight:normal;
            }
            h1{
                padding:0px;
                margin:0px;
                font-size:26px;
                
            }
            h2{
                padding:0px;
                margin:0px;
                font-size:18px;
                
            }
            h3{
                padding:0px;
                margin:0px;
                font-size:13px;
            }
            h4{
                padding:0px;
                margin:0px;
                font-weight:normal;
                font-size:15px;
            }
            .head-th{
                font-size:12px;
                
            }
            hr{
                padding:0px;
                margin:2px;
            }
            .tdr{
                padding:5px;
                font-weight:bold;
                border:solid 1px #fff;
            }
            .tdrr{
                padding:10px;
                font-weight:bold;
                /* border:solid 1px #000; */
            }
            .colm{
                padding:5px;
                font-weight:normal;
                border:solid 1px #fff;
            }
            .cols{
                padding:8px;
                font-weight:normal;
            }
        </style>
    </head>
    <body>
        
            <table width="100%" >
                <tr>
                    <td class="colm" width="5%"></td>
                    <td class="colm" align="center">I.</td>
                    <td class="colm"></td>
                </tr>
            </table>  
            
            
            <div style="height:430px;width:100%"></div>
      
    </body>
</html>