<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Domlak extends Model
{
    protected $table = 'domlak';
    public $timestamps = false;
}
