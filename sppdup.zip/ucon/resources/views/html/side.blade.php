<ul class="sidebar-menu" data-widget="tree">
        <li>
          <a href="{{url('/')}}">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="header">MENU</li>
        <li class="treeview menu-open" style="height: auto;">
          <a href="#">
            <i class="fa fa-th"></i>
            <span>Master</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu" style="display: block;">
            <li><a href="{{url('/bidang')}}"><i class="fa fa-check"></i> Bidang</a></li>
            <li><a href="{{url('/golongan')}}"><i class="fa fa-check"></i> Golongan</a></li>
            <li><a href="{{url('/domlak')}}"><i class="fa fa-check"></i> SSH</a></li>
            <li><a href="{{url('/jasa')}}"><i class="fa fa-check"></i> Jasa Perjalanan</a></li>
            <li><a href="{{url('/employe')}}"><i class="fa fa-check"></i> Pengaturan Umum</a></li>
          </ul>
        </li>
        @foreach(menu() as $menu)
          <li>
            <a href="{{url(acces($menu->route_id)->link)}}">
              <i class="fa fa-{{acces($menu->route_id)->icon}}"></i> <span>{{acces($menu->route_id)->name}}</span>
            </a>
          </li>
        @endforeach
        
      </ul>