<style>
    .dataTables_filter{
        float:right;
    }
    td{
        font-size: 13px;
    }
    th{
        font-size: 13px;
    }
</style>
<?php $__env->startSection('content'); ?>
<section class="content">
      <div class="row">
        <div class="col-xs-12">
            
          

          <div class="box">
            <div class="box-body">
                <form method="post" action="<?php echo e(url('/group/save')); ?>">   
                    <div class="mailbox-controls" style="background:#d6d6e3;margin-bottom:10px">
                        <!-- Check all button -->
                        <?php if(cek_permision_role(5)=='All' || cek_permision_role(5)=='Create'): ?>
                            <span  data-toggle="modal" data-target="#modalreplay" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></span>
                        <?php endif; ?>
                            <span  class="btn btn-success btn-sm" onclick="print()"><i class="fa fa-print"></i></span>
                            <span  class="btn btn-default btn-sm" onclick="download()"><i class="fa fa-download"></i></span>
                            
                        
                        <!-- /.btn-group -->
                        <button type="button" class="btn btn-default btn-sm" onclick="reload()"><i class="fa fa-refresh"></i></button>
                        <div class="pull-right">
                        
                        </div>
                        <!-- /.pull-right -->
                    </div>
                
                    <?php echo csrf_field(); ?>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>Nama Kegiatan</th>
                                <th>Jumlah</th>
                                <th>Kode Rekening</th>
                                <th>Author</th>
                                <th width="8%"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $kegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$kegiatan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+1); ?></td>
                                    <td><?php echo e($kegiatan->title); ?></td>
                                    <td><?php echo e($kegiatan->jumlah); ?></td>
                                    <td><?php echo e($kegiatan->kode_rekening); ?></td>
                                    <td><?php echo e(author($kegiatan->users_id)); ?></td>
                                    <td>
                                    <?php if(cek_permision_role(5)=='All' || cek_permision_role(5)=='Create'): ?>
                                        <div class="btn-group">
                                            <span  class="btn btn-default btn-sm" onclick="delete_data(<?php echo e($kegiatan->id); ?>)"><i class="fa fa-trash-o"></i></span>
                                            <span  data-toggle="modal" data-target="#modalreplay<?php echo e($kegiatan->id); ?>" class="btn btn-default btn-sm"><i class="fa fa-pencil"></i></span>
                                        </div>
                                    <?php else: ?>
                                        No Akses
                                    <?php endif; ?>
                                    </td>
                                 </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                </form>
            </div>
            <!-- /.box-body -->
          </div>
         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
</section>
<?php $__currentLoopData = $modalkegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$modalpegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalreplay<?php echo e($modalpegawai->id); ?>">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Form Kegiatan</h4>
            </div>
            <form method="post" id="myform<?php echo e($modalpegawai->id); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($modalpegawai->id); ?>">
                <div class="modal-body">
                    <div id="alertnya<?php echo e($modalpegawai->id); ?>" style="padding:10px;background:#dfdff7;font-weight:bold">
                    </div>
                    <div class="form-group">
                        <label>Nama Kegiatan:</label>
                        <input type="text" class="form-control" id="title" value="<?php echo e($modalpegawai->title); ?>" name="title">
                    </div>
                    <div class="form-group">
                        <label>Kode Rekening:</label>
                        <input type="text" class="form-control" id="kode_rekening" value="<?php echo e($modalpegawai->kode_rekening); ?>" name="kode_rekening">
                    </div>
                    <div class="form-group">
                        <label>Jumlah:</label>
                        <select class="form-control select2" name="jumlah" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            <option value="">Pilih Jumlah</option>
                            <?php for($x=1;$x<40;$x++): ?>
                                <option value="<?php echo e($x); ?>" <?php if($modalpegawai->jumlah==$x): ?> selected <?php endif; ?>> <?php echo e($x); ?> Pegawai</option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default " data-dismiss="modal">Tutup</button>
                    <button type="button" id="simpan<?php echo e($modalpegawai->id); ?>" Onclick="simpan_data(<?php echo e($modalpegawai->id); ?>);" class="btn btn-primary pull-left">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalreplay">
    <div class="modal-dialog modal-lg">
        <div class="modal-content ">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Form Golongan</h4>
            </div>
            <form method="post" id="myform" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div id="alertnya" style="padding:10px;background:#dfdff7;font-weight:bold">
                    </div>
                    <div class="form-group">
                        <label>Nama Kegiatan:</label>
                        <input type="text" class="form-control" id="title" name="title">
                    </div>
                    <div class="form-group">
                        <label>Kode Rekening:</label>
                        <input type="text" class="form-control" id="kode_rekening" name="kode_rekening">
                    </div>
                    <div class="form-group">
                        <label>Jumlah:</label>
                        <select class="form-control select2" name="jumlah" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            <option value="">Pilih Jumlah</option>
                            <?php for($x=1;$x<40;$x++): ?>
                                <option value="<?php echo e($x); ?>"> <?php echo e($x); ?> Pegawai</option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default " data-dismiss="modal">Tutup</button>
                    <button type="button" id="simpan" Onclick="simpan_data_()" class="btn btn-primary pull-left">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="notifikasi">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Warning</h4>
            </div>
            <div class="modal-body">
                <div id="alertnyas" style="padding:10px;background:#dfdff7;font-weight:bold;text-align:center">
                    <h4>Sukses Tersimpan</h4>
                </div>
            </div>
            <div class="modal-footer">
            <span  class="btn btn-default pull-left" data-dismiss="modal">Close</span>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="notifikasidelete">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Warning</h4>
            </div>
            <div class="modal-body">
                <div id="alertnyas" style="padding:10px;background:#dfdff7;font-weight:bold;text-align:center">
                    <h4>Sukses Terhapus</h4>
                </div>
            </div>
            <div class="modal-footer">
            <span  class="btn btn-default pull-left" data-dismiss="modal">Close</span>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('datatable'); ?>
<?php $__currentLoopData = $alert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script>
        $( document ).ready(function() {
            $("#alertnya<?php echo e($alert->id); ?>").hide();
        });

    </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>

function print(){
    window.location.assign("<?php echo e(url('/kegiatan/pdf/kegiatan')); ?>");
}

function download(){
    window.location.assign("<?php echo e(url('/kegiatan/pdf/download')); ?>");
}

function reload(){
    location.reload();
}

function delete_data(a){
    $.ajax({
        type: 'GET',
        url: "<?php echo e(url('/kegiatan/delete/')); ?>/"+a,
        data: 'id='+a,
        success: function(msg){
            
            window.location.assign("<?php echo e(url('/kegiatan/hapus')); ?>");
            
        }
    });
}
  $(function () {
    $('#example1').DataTable({
        'paging'      : true,
        'lengthChange': true,
        'searching'   : true,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false
    })
  })
</script>
<script>
    $( document ).ready(function() {
        $('#alertnya').hide();
    });
    <?php if($notif=='sukses'): ?>
        $('#notifikasi').modal("toggle");
    <?php endif; ?>

    <?php if($notif=='hapus'): ?>
        $('#notifikasidelete').modal("toggle");
    <?php endif; ?>

    function simpan_data_(){
        var form=document.getElementById('myform');
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('/kegiatan/save/new')); ?>",
          data: new FormData(form),
          contentType: false,
          cache: false,
          processData:false,
          beforeSend: function(){
            $('#simpan').attr("disabled","disabled");
          },
          success: function(msg){
            if(msg=='ok'){
                window.location.assign("<?php echo e(url('/kegiatan/sukses')); ?>");
            }else{
              $('#alertnya').show();
              $('#alertnya').html(msg);
              $("#simpan").removeAttr("disabled");
            }
            
          }
        });
        //alert('dfdsfsd');
    }

    function simpan_data(a){
        var form=document.getElementById('myform'+a);
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('/kegiatan/save/edit')); ?>",
          data: new FormData(form),
          contentType: false,
          cache: false,
          processData:false,
          beforeSend: function(){
            $('#simpan'+a).attr("disabled","disabled");
          },
          success: function(msg){
            if(msg=='ok'){
                window.location.assign("<?php echo e(url('/kegiatan/sukses')); ?>");
            }else{
              $('#alertnya'+a).show();
              $('#alertnya'+a).html(msg);
              $("#simpan"+a).removeAttr("disabled");
            }
            
          }
        });
        //alert('dfdsfsd');
    }

    
    function delete_group(){
        var form=document.getElementById('formdelete');
        $.ajax({
			type: 'POST',
			url: "<?php echo e(url('/group/delete')); ?>",
			data: new FormData(form),
			contentType: false,
			cache: false,
			processData:false,
			success: function(msg){
				window.location.assign("<?php echo e(url('/group')); ?>");
				
			}
		});
    }

    function edit_group(a){
        var form=document.getElementById('save'+a);
        $.ajax({
			type: 'POST',
			url: "<?php echo e(url('/group/update')); ?>/"+a,
			data: new FormData(form),
			contentType: false,
			cache: false,
			processData:false,
			beforeSend: function(){
				$('#simpan'+a).attr("disabled","disabled");
			},
			success: function(msg){
				if(msg=='ok'){
					window.location.assign("<?php echo e(url('/guru/suksess')); ?>");
				}else{
					$('#alert'+a).show();
					$('#alert'+a).html(msg);
					$("#simpan"+a).removeAttr("disabled");
				}
				
			}
		});
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('html.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>