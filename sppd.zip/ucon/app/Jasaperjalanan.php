<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jasaperjalanan extends Model
{
    protected $table = 'jasa_perjalanan';
    public $timestamps = false;
}
