<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Hasrole extends Model
{
    protected $table = 'has_role';
    public $timestamps = false;
}