<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jenissppd extends Model
{
    protected $table = 'jenis_sppd';
    public $timestamps = false;
}
