<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Surattugas extends Model
{
    protected $table = 'surat_tugas';
    public $timestamps = false;
}
