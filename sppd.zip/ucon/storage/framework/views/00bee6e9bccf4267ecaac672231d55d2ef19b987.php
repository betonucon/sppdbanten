<ul class="sidebar-menu" data-widget="tree">
        <li>
          <a href="<?php echo e(url('/')); ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="header">MENU</li>
        
        <?php $__currentLoopData = menu(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($menu->route_id==6): ?>
            <li class="treeview menu-open" style="height: auto;">
              <a href="#">
                <i class="fa fa-<?php echo e(acces($menu->route_id)->icon); ?>"></i>
                <span><?php echo e(acces($menu->route_id)->name); ?></span>
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu" style="display: block;">
                <?php $__currentLoopData = sub_menu(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="<?php echo e(url(acces($sub->route_id)->link)); ?>"><i class="fa fa-check"></i> <?php echo e(acces($sub->route_id)->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </li>
          <?php else: ?>
            <li>
              <a href="<?php echo e(url(acces($menu->route_id)->link)); ?>">
                <i class="fa fa-<?php echo e(acces($menu->route_id)->icon); ?>"></i> <span><?php echo e(acces($menu->route_id)->name); ?></span>
              </a>
            </li>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </ul>