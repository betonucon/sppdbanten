<style>
    .dataTables_filter{
        float:right;
    }
    td{
        font-size: 13px;
    }
    th{
        font-size: 13px;
    }
</style>
<?php $__env->startSection('content'); ?>
<section class="content">
      <div class="row">
        <div class="col-xs-12">
            
          

          <div class="box">
            <div class="box-body">
                <form method="post" action="<?php echo e(url('/group/save')); ?>">   
                    <div class="mailbox-controls" style="background:#d6d6e3;margin-bottom:10px">
                        <!-- Check all button -->
                        <?php if(cek_permision_role(6)=='All' || cek_permision_role(6)=='Create'): ?>
                            <span  data-toggle="modal" data-target="#modalreplay" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></span>
                        <?php endif; ?>
                            <span  class="btn btn-success btn-sm" onclick="print()"><i class="fa fa-print"></i></span>
                            <span  class="btn btn-default btn-sm" onclick="download()"><i class="fa fa-download"></i></span>
                            
                        
                        <!-- /.btn-group -->
                        <button type="button" class="btn btn-default btn-sm" onclick="reload()"><i class="fa fa-refresh"></i></button>
                        <div class="pull-right">
                        
                        </div>
                        <!-- /.pull-right -->
                    </div>
                
                    <?php echo csrf_field(); ?>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>NIP</th>
                                <th>Pangkat</th>
                                <th>Golongan</th>
                                <th>Jabatan</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+1); ?></td>
                                    <td><?php echo e($pegawai->nama); ?></td>
                                    <td><?php echo e($pegawai->nip); ?></td>
                                    <td><?php echo e($pegawai->pangkat); ?></td>
                                    <td><?php echo e($pegawai->golongan); ?></td>
                                    <td><?php echo e($pegawai->jabatan); ?></td>
                                    <td>
                                    <?php if(cek_permision_role(6)=='All' || cek_permision_role(6)=='Create'): ?>
                                        <div class="btn-group">
                                            <span  class="btn btn-default btn-sm" onclick="delete_data(<?php echo e($pegawai->id); ?>)"><i class="fa fa-trash-o"></i></span>
                                            <span  data-toggle="modal" data-target="#modalreplay<?php echo e($pegawai->id); ?>" class="btn btn-default btn-sm"><i class="fa fa-pencil"></i></span>
                                        </div>
                                    <?php else: ?>
                                        No Akses
                                    <?php endif; ?>
                                    </td>
                                 </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                </form>
            </div>
            <!-- /.box-body -->
          </div>
         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
</section>
<?php $__currentLoopData = $modalpegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$modalpegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalreplay<?php echo e($modalpegawai->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Form Pegawai</h4>
            </div>
            <form method="post" id="myform<?php echo e($modalpegawai->id); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($modalpegawai->id); ?>">
                <div class="modal-body">
                    <div id="alertnya<?php echo e($modalpegawai->id); ?>" style="padding:10px;background:#dfdff7;font-weight:bold">
                    </div>
                    <div class="form-group">
                        <label>NIP:</label>
                        <input type="text" class="form-control" id="nip" name="nip" value="<?php echo e($modalpegawai->nip); ?>">
                    </div>
                    <div class="form-group">
                        <label>Nama:</label>
                        <input type="text" class="form-control" id="nama" name="nama" value="<?php echo e($modalpegawai->nama); ?>">
                    </div>
                    <div class="form-group">
                        <label>Jabatan:</label>
                        <input type="text" class="form-control" id="jabatan" name="jabatan" value="<?php echo e($modalpegawai->jabatan); ?>">
                    </div>
                    <div class="form-group">
                        <label>Pangkat:</label>
                        <input type="text" class="form-control" id="pangkat" name="pangkat" value="<?php echo e($modalpegawai->pangkat); ?>">
                    </div>
                    <div class="form-group">
                        <label>No Rekening:</label>
                        <input type="text" class="form-control" id="nomor_rekening" name="nomor_rekening" value="<?php echo e($modalpegawai->nomor_rekening); ?>">
                    </div>
                    <div class="form-group">
                        <label>Golongan:</label>
                        <select class="form-control select2" name="golongan" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            <option value="">Pilih Golongan</option>
                            <?php $__currentLoopData = golongan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $golongan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($golongan->golongan); ?>" <?php if($modalpegawai->golongan==$golongan->golongan): ?> selected <?php endif; ?>>Golongan <?php echo e($golongan->golongan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status:</label>
                        <select class="form-control select2" name="status" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            <option value="1" <?php if($modalpegawai->status==1): ?> selected <?php endif; ?>>Aktif</option>
                            <option value="0" <?php if($modalpegawai->status==2): ?> selected <?php endif; ?>>Non Aktif</option>
                            
                        </select>
                    </div>
                    <!-- <div class="form-group">
                        <label>Replay</label>

                        <div class="input-group">
                            <textarea id="editor1" name="editor1" rows="20" cols="80"></textarea>
                        </div>
                    </div> -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default " data-dismiss="modal">Tutup</button>
                    <button type="button" id="simpan<?php echo e($modalpegawai->id); ?>" Onclick="simpan_data(<?php echo e($modalpegawai->id); ?>);" class="btn btn-primary pull-left">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalreplay">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Form Pegawai</h4>
            </div>
            <form method="post" id="myform" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div id="alertnya" style="padding:10px;background:#dfdff7;font-weight:bold">
                    </div>
                    <div class="form-group">
                        <label>NIP:</label>
                        <input type="text" class="form-control" id="nip" name="nip">
                    </div>
                    <div class="form-group">
                        <label>Nama:</label>
                        <input type="text" class="form-control" id="nama" name="nama">
                    </div>
                    <div class="form-group">
                        <label>Jabatan:</label>
                        <input type="text" class="form-control" id="jabatan" name="jabatan">
                    </div>
                    <div class="form-group">
                        <label>Pangkat:</label>
                        <input type="text" class="form-control" id="pangkat" name="pangkat">
                    </div>
                    <div class="form-group">
                        <label>No Rekening:</label>
                        <input type="text" class="form-control" id="nomor_rekening" name="nomor_rekening">
                    </div>
                    <div class="form-group">
                        <label>Golongan:</label>
                        <select class="form-control select2" name="golongan" style="width: 100%;" data-select2-id="8" tabindex="-1" aria-hidden="true">
                            <option value="">Pilih Golongan</option>
                            <?php $__currentLoopData = golongan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $golongan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($golongan->golongan); ?>">Golongan <?php echo e($golongan->golongan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Status:</label>
                        <select class="form-control select2" name="status" style="width: 100%;" data-select2-id="9" tabindex="-1" aria-hidden="true">
                            <option value="1">Aktif</option>
                            <option value="0">Non Aktif</option>
                            
                        </select>
                    </div>
                    <!-- <div class="form-group">
                        <label>Replay</label>

                        <div class="input-group">
                            <textarea id="editor1" name="editor1" rows="20" cols="80"></textarea>
                        </div>
                    </div> -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default " data-dismiss="modal">Tutup</button>
                    <button type="button" id="simpan" Onclick="simpan_data();" class="btn btn-primary pull-left">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="notifikasi">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Warning</h4>
            </div>
            <div class="modal-body">
                <div id="alertnyas" style="padding:10px;background:#dfdff7;font-weight:bold;text-align:center">
                    <h4>Sukses Tersimpan</h4>
                </div>
            </div>
            <div class="modal-footer">
            <span  class="btn btn-default pull-left" data-dismiss="modal">Close</span>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="notifikasidelete">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Warning</h4>
            </div>
            <div class="modal-body">
                <div id="alertnyas" style="padding:10px;background:#dfdff7;font-weight:bold;text-align:center">
                    <h4>Sukses Terhapus</h4>
                </div>
            </div>
            <div class="modal-footer">
            <span  class="btn btn-default pull-left" data-dismiss="modal">Close</span>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('datatable'); ?>
<?php $__currentLoopData = $alert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script>
        $( document ).ready(function() {
            $("#alertnya<?php echo e($alert->id); ?>").hide();
        });

        function print(){
            window.location.assign("<?php echo e(url('/pegawai/pdf/pegawai')); ?>","_blank");
        }

        function download(){
            window.location.assign("<?php echo e(url('/pegawai/pdf/download')); ?>");
        }

        function reload(){
            location.reload();
        }

        function delete_data(a){
            $.ajax({
                type: 'GET',
                url: "<?php echo e(url('/pegawai/delete/')); ?>/"+a,
                data: 'id='+a,
                success: function(msg){
                   
                    window.location.assign("<?php echo e(url('/pegawai/hapus')); ?>");
                    
                }
            });
        }
    </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
  $(function () {
    $('#example1').DataTable({
        'paging'      : true,
        'lengthChange': true,
        'searching'   : true,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false
    })
  })
</script>
<script>
    $( document ).ready(function() {
        $('#alertnya').hide();
    });
    <?php if($notif=='sukses'): ?>
        $('#notifikasi').modal("toggle");
    <?php endif; ?>

    <?php if($notif=='hapus'): ?>
        $('#notifikasidelete').modal("toggle");
    <?php endif; ?>

    function simpan_data(){
        var form=document.getElementById('myform');
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('/pegawai/save/new')); ?>",
          data: new FormData(form),
          contentType: false,
          cache: false,
          processData:false,
          beforeSend: function(){
            $('#simpan').attr("disabled","disabled");
          },
          success: function(msg){
            if(msg=='ok'){
                window.location.assign("<?php echo e(url('/pegawai/sukses')); ?>");
            }else{
              $('#alertnya').show();
              $('#alertnya').html(msg);
              $("#simpan").removeAttr("disabled");
            }
            
          }
        });
        //alert('dfdsfsd');
    }

    function simpan_data(a){
        var form=document.getElementById('myform'+a);
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('/pegawai/save/edit')); ?>",
          data: new FormData(form),
          contentType: false,
          cache: false,
          processData:false,
          beforeSend: function(){
            $('#simpan'+a).attr("disabled","disabled");
          },
          success: function(msg){
            if(msg=='ok'){
                window.location.assign("<?php echo e(url('/pegawai/sukses')); ?>");
            }else{
              $('#alertnya'+a).show();
              $('#alertnya'+a).html(msg);
              $("#simpan"+a).removeAttr("disabled");
            }
            
          }
        });
        //alert('dfdsfsd');
    }

    
    function delete_group(){
        var form=document.getElementById('formdelete');
        $.ajax({
			type: 'POST',
			url: "<?php echo e(url('/group/delete')); ?>",
			data: new FormData(form),
			contentType: false,
			cache: false,
			processData:false,
			success: function(msg){
				window.location.assign("<?php echo e(url('/group')); ?>");
				
			}
		});
    }

    function edit_group(a){
        var form=document.getElementById('save'+a);
        $.ajax({
			type: 'POST',
			url: "<?php echo e(url('/group/update')); ?>/"+a,
			data: new FormData(form),
			contentType: false,
			cache: false,
			processData:false,
			beforeSend: function(){
				$('#simpan'+a).attr("disabled","disabled");
			},
			success: function(msg){
				if(msg=='ok'){
					window.location.assign("<?php echo e(url('/guru/suksess')); ?>");
				}else{
					$('#alert'+a).show();
					$('#alert'+a).html(msg);
					$("#simpan"+a).removeAttr("disabled");
				}
				
			}
		});
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('html.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>