<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Permision extends Model
{
    protected $table = 'permision';
    public $timestamps = false;
}
