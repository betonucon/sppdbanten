<html>
    <head>
        <title>Daftar Pegawai</title>
        <style>
            table{
                border-collapse:collapse;
            }
            th{
                border:solid 1px #000;
                padding:5px;
                font-size:11px;
                

            }
            td{
                border:solid 1px #000;
                padding:5px;
                font-size:10px;
                vertical-align:top;
            }
        </style>
    </head>
    <body>
        <table width="100%">
            <thead>
                <tr>
                    <th width="5%">No</th>
                    <th>Nama</th>
                    <th>NIP</th>
                    <th>Pangkat</th>
                    <th width="10%">Golongan</th>
                    <th>Jabatan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($no+1); ?></td>
                        <td><?php echo e($pegawai->nama); ?></td>
                        <td><?php echo e($pegawai->nip); ?></td>
                        <td><?php echo e($pegawai->pangkat); ?></td>
                        <td><?php echo e($pegawai->golongan); ?></td>
                        <td><?php echo e($pegawai->jabatan); ?></td>
                       
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
    </body>
</html>