<style>
    .dataTables_filter{
        float:right;
    }
    td{
        font-size: 13px;
        padding:6px;
    }
    th{
        font-size: 13px;
       
    }
    .tth{
        font-size: 13px;
        padding:6px;
        background:aqua;
    }
    .ttd{
        font-size: 13px;
        padding:6px;
    }
</style>
<?php $__env->startSection('content'); ?>
<section class="content">
      <div class="row">
        <div class="col-xs-12">
            
          

          <div class="box">
            <div class="box-body">
                <form method="post" action="<?php echo e(url('/group/save')); ?>">   
                    <div class="mailbox-controls" style="background:#d6d6e3;margin-bottom:10px">
                        <!-- Check all button -->
                        
                            <span  data-toggle="modal" data-target="#modalreplay" class="btn btn-primary btn-sm"><i class="fa fa-pencil"></i></span>
                            <!-- <span  class="btn btn-success btn-sm" onclick="print()"><i class="fa fa-print"></i></span>
                            <span  class="btn btn-default btn-sm" onclick="download()"><i class="fa fa-download"></i></span> -->
                            
                        
                        <!-- /.btn-group -->
                        <button type="button" class="btn btn-default btn-sm" onclick="reload()"><i class="fa fa-refresh"></i></button>
                        <div class="pull-right">
                        
                        </div>
                        <!-- /.pull-right -->
                    </div>
                
                    <?php echo csrf_field(); ?>
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>Keterangan</th>
                                <th>Role</th>
                                <th width="5%">App</th>
                                <th width="10%"></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no+1); ?></td>
                                    <td>App/Laravel</td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><span  data-keyboard="false" data-backdrop="static" data-toggle="modal" data-target="#modalapp<?php echo e($user->id); ?>" class="btn btn-default btn-sm"><i class="fa fa-plus"></i></span></td>
                                    <td>
                                        <div class="btn-group">
                                            <span  class="btn btn-default btn-sm" onclick="delete_data(<?php echo e($user->id); ?>)"><i class="fa fa-trash-o"></i></span>
                                            <span  data-toggle="modal" data-target="#modalreplay<?php echo e($user->id); ?>" class="btn btn-default btn-sm"><i class="fa fa-pencil"></i></span>
                                        </div>
                                    </td>
                                 </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        
                    </table>
                </form>
            </div>
            <!-- /.box-body -->
          </div>
         
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
</section>
<?php $__currentLoopData = $modaluser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$modalpegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalreplay<?php echo e($modalpegawai->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Form Pegawai</h4>
            </div>
            <form method="post" id="myform<?php echo e($modalpegawai->id); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($modalpegawai->id); ?>">
                <div class="modal-body">
                    <div id="alertnya<?php echo e($modalpegawai->id); ?>" style="padding:10px;background:#dfdff7;font-weight:bold">
                    </div>
                    <div class="form-group">
                        <label>Nama Role:</label>
                        <input type="text" class="form-control" value="<?php echo e($modalpegawai->name); ?>" id="name" name="name">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default " data-dismiss="modal">Tutup</button>
                    <button type="button" id="simpan<?php echo e($modalpegawai->id); ?>" Onclick="simpan_data(<?php echo e($modalpegawai->id); ?>);" class="btn btn-primary pull-left">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="modalapp<?php echo e($modalpegawai->id); ?>">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Form Akses</h4>
            </div>
            <form method="post" id="myformroute<?php echo e($modalpegawai->id); ?>" enctype="multipart/form-data">
            <!-- <form method="post" action="<?php echo e(url('/user/save/'.$modalpegawai->id)); ?>" enctype="multipart/form-data"> -->
            <?php echo csrf_field(); ?>
                <input type="hidden" name="id" value="<?php echo e($modalpegawai->id); ?>">
                <input type="hidden" name="role_id" value="<?php echo e($modalpegawai->id); ?>">
                <div class="modal-body">
                    <!-- <div id="alertnya<?php echo e($modalpegawai->id); ?>" style="padding:10px;background:#dfdff7;font-weight:bold">
                    </div> -->
                    <table width="100%">
                        <tr>
                            <th class="tth" width="10%">NO</th>
                            <th class="tth" >Modul</th>
                            <th class="tth" width="15%">Permision</th>
                        </tr>
                        <?php $__currentLoopData = $rout; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $routs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="ttd"><input type="checkbox" value="<?php echo e($routs->id); ?>" <?php echo e($check->shift()['check']); ?> name="route_id<?php echo e($modalpegawai->id); ?>[<?php echo e($routs->id); ?>]"></td>
                            <td class="ttd"><?php echo e($routs->name); ?></td>
                            <td class="ttd">
                                <select name="permision_id<?php echo e($modalpegawai->id); ?>[<?php echo e($routs->id); ?>]">
                                    <?php $__currentLoopData = permision(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permision): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($permision->id); ?>" <?php echo e($hase->shift()['selected']); ?> ><?php echo e($permision->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default " data-dismiss="modal">Tutup</button>
                    <button type="button" id="simpan_route<?php echo e($modalpegawai->id); ?>" Onclick="simpan_route(<?php echo e($modalpegawai->id); ?>);" class="btn btn-primary pull-left">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modalreplay">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Form Role</h4>
            </div>
            <form method="post" id="myform" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div id="alertnya" style="padding:10px;background:#dfdff7;font-weight:bold">
                    </div>
                    <div class="form-group">
                        <label>Nama Role:</label>
                        <input type="text" class="form-control" id="name" name="name">
                    </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default " data-dismiss="modal">Tutup</button>
                    <button type="button" id="simpan" Onclick="simpan_data_()" class="btn btn-primary pull-left">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="notifikasi">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Warning</h4>
            </div>
            <div class="modal-body">
                <div id="alertnyas" style="padding:10px;background:#dfdff7;font-weight:bold;text-align:center">
                    <h4>Sukses Tersimpan</h4>
                </div>
            </div>
            <div class="modal-footer">
            <span  class="btn btn-default pull-left" onclick="close_notif()"  data-dismiss="modal">Close</span>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="notifikasidelete">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title">Warning</h4>
            </div>
            <div class="modal-body">
                <div id="alertnyas" style="padding:10px;background:#dfdff7;font-weight:bold;text-align:center">
                    <h4>Sukses Terhapus</h4>
                </div>
            </div>
            <div class="modal-footer">
            <span  class="btn btn-default pull-left" onclick="close_notif()" data-dismiss="modal">Close</span>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('datatable'); ?>
<?php $__currentLoopData = $alert; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $no=>$alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <script>
        $( document ).ready(function() {
            $("#alertnya<?php echo e($alert->id); ?>").hide();
        });

    </script>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>

function print(){
    window.location.assign("<?php echo e(url('/golongan/pdf/golongan')); ?>");
}

function download(){
    window.location.assign("<?php echo e(url('/golongan/pdf/download')); ?>");
}

function reload(){
    location.reload();
}

function delete_data(a){
    $.ajax({
        type: 'GET',
        url: "<?php echo e(url('/user/delete/')); ?>/"+a,
        data: 'id='+a,
        success: function(msg){
            
            window.location.assign("<?php echo e(url('/user/hapus')); ?>");
            
        }
    });
}
  $(function () {
    $('#example1').DataTable({
        'paging'      : true,
        'lengthChange': true,
        'searching'   : true,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false
    })
  })
</script>
<script>
    $( document ).ready(function() {
        $('#alertnya').hide();
    });
    function close_notif(){
        window.location.assign("<?php echo e(url('/user/')); ?>");
    }
    <?php if($notif=='sukses'): ?>
        $('#notifikasi').modal({
    		backdrop: 'static',
    		keyboard: false});
    <?php endif; ?>

    <?php if($notif=='hapus'): ?>
       
        $('#notifikasidelete').modal({
    		backdrop: 'static',
    		keyboard: false});
    <?php endif; ?>

    function simpan_data_(){
        var form=document.getElementById('myform');
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('/user/user_role/new')); ?>",
          data: new FormData(form),
          contentType: false,
          cache: false,
          processData:false,
          beforeSend: function(){
            $('#simpan').attr("disabled","disabled");
          },
          success: function(msg){
            if(msg=='ok'){
                window.location.assign("<?php echo e(url('/user/sukses')); ?>");
            }else{
              $('#alertnya').show();
              $('#alertnya').html(msg);
              $("#simpan").removeAttr("disabled");
            }
            
          }
        });
        //alert('dfdsfsd');
    }

    function simpan_route(a){
        var form=document.getElementById('myformroute'+a);
        //alert(a);
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('/user/save/')); ?>/"+a,
          data: new FormData(form),
          contentType: false,
          cache: false,
          processData:false,
          beforeSend: function(){
            $('#simpan_route'+a).attr("disabled","disabled");
          },
          success: function(msg){
            if(msg=='ok'){
                window.location.assign("<?php echo e(url('/user/sukses')); ?>");
            }else{
              $("#simpan_route"+a).removeAttr("disabled");
              alert(msg);
            }
            
          }
        });
        //alert('dfdsfsd');
    }

    function simpan_data(a){
        var form=document.getElementById('myform'+a);
        $.ajax({
          type: 'POST',
          url: "<?php echo e(url('/user/user_role/edit')); ?>",
          data: new FormData(form),
          contentType: false,
          cache: false,
          processData:false,
          beforeSend: function(){
            $('#simpan'+a).attr("disabled","disabled");
          },
          success: function(msg){
            if(msg=='ok'){
                window.location.assign("<?php echo e(url('/user/sukses')); ?>");
            }else{
              $('#alertnya'+a).show();
              $('#alertnya'+a).html(msg);
              $("#simpan"+a).removeAttr("disabled");
            }
            
          }
        });
        //alert('dfdsfsd');
    }

    
    function delete_group(){
        var form=document.getElementById('formdelete');
        $.ajax({
			type: 'POST',
			url: "<?php echo e(url('/group/delete')); ?>",
			data: new FormData(form),
			contentType: false,
			cache: false,
			processData:false,
			success: function(msg){
				window.location.assign("<?php echo e(url('/group')); ?>");
				
			}
		});
    }

    function edit_group(a){
        var form=document.getElementById('save'+a);
        $.ajax({
			type: 'POST',
			url: "<?php echo e(url('/group/update')); ?>/"+a,
			data: new FormData(form),
			contentType: false,
			cache: false,
			processData:false,
			beforeSend: function(){
				$('#simpan'+a).attr("disabled","disabled");
			},
			success: function(msg){
				if(msg=='ok'){
					window.location.assign("<?php echo e(url('/guru/suksess')); ?>");
				}else{
					$('#alert'+a).show();
					$('#alert'+a).html(msg);
					$("#simpan"+a).removeAttr("disabled");
				}
				
			}
		});
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('html.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>