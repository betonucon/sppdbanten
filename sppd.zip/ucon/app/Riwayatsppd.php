<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Riwayatsppd extends Model
{
    protected $table = 'riwayat_sppd';
    public $timestamps = false;
}
