<ul class="sidebar-menu" data-widget="tree">
        <li>
          <a href="<?php echo e(url('/')); ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="header">MENU</li>
        <li class="treeview menu-open" style="height: auto;">
          <a href="#">
            <i class="fa fa-th"></i>
            <span>Master</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu" style="display: block;">
            <li><a href="<?php echo e(url('/bidang')); ?>"><i class="fa fa-check"></i> Bidang</a></li>
            <li><a href="<?php echo e(url('/golongan')); ?>"><i class="fa fa-check"></i> Golongan</a></li>
            <li><a href="<?php echo e(url('/domlak')); ?>"><i class="fa fa-check"></i> SSH</a></li>
            <li><a href="<?php echo e(url('/jasa')); ?>"><i class="fa fa-check"></i> Jasa Perjalanan</a></li>
            <li><a href="<?php echo e(url('/employe')); ?>"><i class="fa fa-check"></i> Pengaturan Umum</a></li>
          </ul>
        </li>
        <?php $__currentLoopData = menu(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li>
            <a href="<?php echo e(url(acces($menu->route_id)->link)); ?>">
              <i class="fa fa-<?php echo e(acces($menu->route_id)->icon); ?>"></i> <span><?php echo e(acces($menu->route_id)->name); ?></span>
            </a>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      </ul>