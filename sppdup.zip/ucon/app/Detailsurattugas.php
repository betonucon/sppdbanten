<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Detailsurattugas extends Model
{
    protected $table = 'detail_surat_tugas';
    public $timestamps = false;
}
